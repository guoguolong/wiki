atlassian-extras-3.2.jar			<安装更目录>\atlassian-jira\WEB-INF\lib
mysql-connector-java-5.1.46-bin.jar		<安装更目录>\lib
atlassian-universal-plugin-manager-plugin-2.22.9.jar <安装更目录>\atlassian-jira\WEB-INF\atlassian-bundled-plugins

替换后需要重启：JIRA服务
windows用户重启方式：cmd: services.msc
linux用户重启方式： <安装目录>/bin/start-jira.sh  stop-jira.sh